// ==UserScript==
// @name         SSH Master
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Copies easy_hustler command to SSH to cluster master
// @author       Pulkit Bhardwaj
// @match        https://www.google.com/search?q=tampermonkey+copy+to+clipboard&oq=tampermonkey+copy+to+clipboard&aqs=chrome.0.69i59j69i60l3.6097j0j7&sourceid=chrome&ie=UTF-8
// @grant        GM_setClipboard
// @require      http://code.jquery.com/jquery-3.4.1.min.js
// ==/UserScript==

(function() {
    'use strict';
    let cluster_tag_element = $("#review-custom-ec2-tags > table > tbody > tr");
    console.log((cluster_tag_element[0].innerText).split('\t')[1]);
    let cluster_tag = (cluster_tag_element[0].innerText).split('\t')[1];
    let cluster_id = cluster_tag.split('_');
    //console.log(cluster_id[cluster_id.length-1]);
    let temp_id = cluster_id[cluster_id.length-1];
    console.log(temp_id.slice(2,temp_id.length));
    let cluster = temp_id.slice(2,temp_id.length);
    console.log(cluster);
    let ssh_command = "easy_hustler --cluster-id "+cluster+" sshmaster "+cluster_tag;
    GM_setClipboard(ssh_command);
    //console.log(ssh_command);
})();