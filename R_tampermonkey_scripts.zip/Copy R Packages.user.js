// ==UserScript==
// @name         Copy R Packages
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Copies a list of commas separated R packages from the current environment page
// @author       Pulkit Bhardwaj
// @match        https://www.google.com/search?q=tampermonkey+copy+to+clipboard&oq=tampermonkey+copy+to+clipboard&aqs=chrome.0.69i59j69i60l3.6097j0j7&sourceid=chrome&ie=UTF-8
// @grant        GM_setClipboard
// @require      http://code.jquery.com/jquery-3.4.1.min.js
// ==/UserScript==

(function() {
    'use strict';
    let env_id = $(".env-id")[0].innerText.split(' ')[1];
    //console.log(env_id);
    let base_url = $(".env-id")[0].baseURI;
    //console.log(base_url);
    let url = new URL(base_url);
    //console.log(url);
    let environment = url.origin;
    //console.log(environment);
    let env_package_url = `${environment}/api/v1.2/package/${env_id}/list_packages.json`;
    //console.log(env_package_url);
    const Http = new XMLHttpRequest();
    Http.open("GET", env_package_url);
    Http.send();
    Http.onreadystatechange = (e) => {
        let response = (Http.responseText);
        //console.log(typeof response);
        let obj = JSON.parse(response);
        //console.log(obj)
        if(obj.packages.r[0]) {
            console.log(obj.packages.r[0].requirements);
            GM_setClipboard(obj.packages.r[0].requirements.toString());
        } else GM_setClipboard('');
    }
})();